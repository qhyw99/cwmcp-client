#!/usr/bin/env bash
set -euo pipefail

MCP_API_KEY_VALUE="94a05d02-9ade-4d9d-9f39-88734d9e34b4"
EDITOR_PROTOCOL_VALUE="trae"

for rc_file in "$HOME/.bashrc" "$HOME/.zshrc"; do
  touch "$rc_file"

  if grep -q '^export MCP_API_KEY=' "$rc_file"; then
    sed -i "s|^export MCP_API_KEY=.*$|export MCP_API_KEY=\"${MCP_API_KEY_VALUE}\"|" "$rc_file"
  else
    printf '\nexport MCP_API_KEY="%s"\n' "$MCP_API_KEY_VALUE" >> "$rc_file"
  fi

  if grep -q '^export EDITOR_PROTOCOL=' "$rc_file"; then
    sed -i "s|^export EDITOR_PROTOCOL=.*$|export EDITOR_PROTOCOL=\"${EDITOR_PROTOCOL_VALUE}\"|" "$rc_file"
  else
    printf 'export EDITOR_PROTOCOL="%s"\n' "$EDITOR_PROTOCOL_VALUE" >> "$rc_file"
  fi
done

if [[ "${BASH_SOURCE[0]}" != "$0" ]]; then
  export MCP_API_KEY="$MCP_API_KEY_VALUE"
  export EDITOR_PROTOCOL="$EDITOR_PROTOCOL_VALUE"
  echo "已写入 ~/.bashrc 和 ~/.zshrc，并在当前会话生效"
else
  echo "已写入 ~/.bashrc 和 ~/.zshrc。请重新打开终端或执行 source ~/.bashrc 生效"
fi
